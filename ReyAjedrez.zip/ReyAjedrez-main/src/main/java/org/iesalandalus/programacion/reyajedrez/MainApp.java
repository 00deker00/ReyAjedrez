package org.iesalandalus.programacion.reyajedrez;

public class MainApp {
    public static void main(String[] args) {

    }
}
